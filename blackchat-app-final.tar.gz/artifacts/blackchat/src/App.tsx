import { Switch, Route, Router as WouterRouter } from "wouter";
import { Toaster } from "sonner";
import { AuthProvider } from "@/contexts/auth-context";
import { ThemeProvider } from "@/contexts/theme-context";
import { CallProvider } from "@/contexts/call-context";
import { MainApp } from "@/components/main-app";
import { ServiceWorkerRegister } from "@/components/service-worker-register";
import AuthPage from "@/pages/auth";
import SetupPage from "@/pages/setup";

const base = import.meta.env.BASE_URL.replace(/\/$/, "");

function Router() {
  return (
    <WouterRouter base={base}>
      <ServiceWorkerRegister />
      <Switch>
        <Route path="/" component={MainApp} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/setup" component={SetupPage} />
      </Switch>
      <Toaster position="top-center" richColors closeButton />
    </WouterRouter>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CallProvider>
          <Router />
        </CallProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
