import { useState, useEffect } from 'react'
import { useLocation } from 'wouter'
import { ref, set, get } from 'firebase/database'
import { database, isFirebaseConfigured } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { User, AtSign, FileText, Smile, Loader2, Check, X, ExternalLink, AlertTriangle } from 'lucide-react'

const POPULAR_EMOJIS = ['😀', '😎', '🚀', '💬', '🔥', '⭐', '💡', '🎯', '🌟', '💪', '🎉', '❤️', '🌈', '🦄', '🐱', '🐶', '🦊', '🐼', '🦁', '🐸']

const FIREBASE_RULES = `{
  "rules": {
    ".read": "auth != null",
    ".write": "auth != null"
  }
}`

export default function SetupPage() {
  const { user, refreshProfile, isConfigured } = useAuth()
  const [, navigate] = useLocation()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [checkingId, setCheckingId] = useState(false)
  const [idAvailable, setIdAvailable] = useState<boolean | null>(null)
  const [showRulesHelp, setShowRulesHelp] = useState(false)

  const [name, setName] = useState('')
  const [bio, setBio] = useState('')
  const [emoji, setEmoji] = useState('😀')
  const [publicId, setPublicId] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isConfigured) {
      navigate('/')
    } else if (!user) {
      navigate('/auth')
    }
  }, [user, navigate, isConfigured])

  useEffect(() => {
    const checkPublicId = async () => {
      if (!publicId || publicId.length < 4) {
        setIdAvailable(null)
        return
      }

      const isValid = /^[a-zA-Z0-9_.]{4,15}$/.test(publicId)
      if (!isValid) {
        setIdAvailable(false)
        return
      }

      setCheckingId(true)
      try {
        if (!database) return
        const idRef = ref(database, `publicIds/${publicId.toLowerCase()}`)
        const snapshot = await get(idRef)
        setIdAvailable(!snapshot.exists())
      } catch {
        // If permission denied, assume available (rules check happens on write)
        setIdAvailable(true)
      } finally {
        setCheckingId(false)
      }
    }

    const debounce = setTimeout(checkPublicId, 500)
    return () => clearTimeout(debounce)
  }, [publicId])

  const handleNext = () => {
    setError('')
    if (step === 1) {
      if (!name.trim()) {
        setError('Please enter your name')
        return
      }
      if (name.length > 20) {
        setError('Name must be 20 characters or less')
        return
      }
      setStep(2)
    } else if (step === 2) {
      if (bio.length > 100) {
        setError('Bio must be 100 characters or less')
        return
      }
      setStep(3)
    }
  }

  const handleSubmit = async () => {
    if (!user || !database) return

    if (!publicId || publicId.length < 4) {
      setError('Public ID must be at least 4 characters')
      return
    }

    if (publicId.length > 15) {
      setError('Public ID must be 15 characters or less')
      return
    }

    const isValid = /^[a-zA-Z0-9_.]{4,15}$/.test(publicId)
    if (!isValid) {
      setError('Public ID can only contain letters, numbers, underscore and dot')
      return
    }

    setLoading(true)
    setError('')
    try {
      const lowerPublicId = publicId.toLowerCase()

      await set(ref(database, `users/${user.uid}`), {
        uid: user.uid,
        email: user.email,
        name: name.trim(),
        bio: bio.trim(),
        emoji,
        publicId: lowerPublicId,
        createdAt: Date.now(),
      })

      await set(ref(database, `publicIds/${lowerPublicId}`), user.uid)

      await refreshProfile()
      navigate('/')
    } catch (err: unknown) {
      const e = err as { message?: string; code?: string }
      const isPermissionError = e?.message?.includes('Permission denied') || e?.code === 'PERMISSION_DENIED'
      if (isPermissionError) {
        setShowRulesHelp(true)
        setError('Firebase Database permission denied. You need to update your security rules.')
      } else {
        setError('Failed to save profile. Please try again.')
      }
    } finally {
      setLoading(false)
    }
  }

  const stepTitles = ['Your Name', 'Your Avatar', 'Your ID']

  if (showRulesHelp) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-lg border-border/50 shadow-2xl">
          <CardHeader className="text-center">
            <div className="mx-auto w-14 h-14 bg-amber-500/10 rounded-full flex items-center justify-center mb-2">
              <AlertTriangle className="w-7 h-7 text-amber-500" />
            </div>
            <CardTitle>Update Firebase Database Rules</CardTitle>
            <CardDescription>
              Your Firebase Realtime Database rules are blocking writes. Follow these steps to fix it:
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
              <li>Open your <strong className="text-foreground">Firebase Console</strong></li>
              <li>Go to <strong className="text-foreground">Realtime Database</strong> → <strong className="text-foreground">Rules</strong></li>
              <li>Replace the rules with the following:</li>
            </ol>
            <pre className="bg-muted rounded-lg p-4 text-xs font-mono overflow-x-auto border border-border">
              {FIREBASE_RULES}
            </pre>
            <p className="text-xs text-muted-foreground">
              These rules allow any authenticated user to read and write. You can tighten them later.
            </p>
            <div className="flex gap-3">
              <Button asChild className="flex-1">
                <a
                  href="https://console.firebase.google.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Firebase Console
                </a>
              </Button>
              <Button variant="outline" onClick={() => { setShowRulesHelp(false); handleSubmit() }}>
                <Loader2 className="w-4 h-4 mr-2" />
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border/50 shadow-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center gap-2 mb-4">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                  s === step
                    ? 'bg-primary text-primary-foreground'
                    : s < step
                    ? 'bg-primary/30 text-primary'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {s < step ? <Check className="w-4 h-4" /> : s}
              </div>
            ))}
          </div>
          <CardTitle>Set Up Your Profile</CardTitle>
          <CardDescription>Step {step} of 3: {stepTitles[step - 1]}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Display Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    maxLength={20}
                    className="h-12"
                    autoFocus
                  />
                  <p className="text-xs text-muted-foreground text-right">{name.length}/20</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Bio <span className="text-muted-foreground">(optional)</span>
                  </Label>
                  <Textarea
                    id="bio"
                    placeholder="Tell others about yourself..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    maxLength={100}
                    rows={3}
                    className="resize-none"
                  />
                  <p className="text-xs text-muted-foreground text-right">{bio.length}/100</p>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-3">
                <Label className="flex items-center gap-2">
                  <Smile className="w-4 h-4" />
                  Choose Your Emoji
                </Label>
                <div className="grid grid-cols-5 gap-3">
                  {POPULAR_EMOJIS.map((e) => (
                    <button
                      key={e}
                      type="button"
                      onClick={() => setEmoji(e)}
                      className={`w-12 h-12 text-2xl flex items-center justify-center rounded-xl transition-all border-2 ${
                        emoji === e
                          ? 'border-primary bg-primary/10 scale-110 shadow-md'
                          : 'border-transparent hover:bg-muted'
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
                <div className="mt-4 flex items-center gap-3 p-3 bg-muted rounded-lg">
                  <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-2xl">
                    {emoji}
                  </div>
                  <div>
                    <p className="font-medium">{name || 'Your Name'}</p>
                    <p className="text-sm text-muted-foreground">This is your avatar</p>
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-2">
                <Label htmlFor="publicId" className="flex items-center gap-2">
                  <AtSign className="w-4 h-4" />
                  Public ID
                </Label>
                <div className="relative">
                  <Input
                    id="publicId"
                    placeholder="your_unique_id"
                    value={publicId}
                    onChange={(e) => setPublicId(e.target.value.toLowerCase())}
                    maxLength={15}
                    className="h-12 pr-10"
                    autoFocus
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {checkingId && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
                    {!checkingId && idAvailable === true && publicId.length >= 4 && <Check className="w-4 h-4 text-green-500" />}
                    {!checkingId && idAvailable === false && <X className="w-4 h-4 text-destructive" />}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  4–15 characters. Letters, numbers, underscore and dot only. Others can find you with this ID.
                </p>
              </div>
            )}

            {error && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <div className="flex gap-3">
              {step > 1 && (
                <Button type="button" variant="outline" className="flex-1 h-12" onClick={() => { setStep(step - 1); setError('') }}>
                  Back
                </Button>
              )}
              {step < 3 ? (
                <Button type="button" className="flex-1 h-12" onClick={handleNext}>
                  Continue
                </Button>
              ) : (
                <Button
                  type="button"
                  className="flex-1 h-12"
                  onClick={handleSubmit}
                  disabled={loading || !publicId || publicId.length < 4}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    'Complete Setup'
                  )}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
