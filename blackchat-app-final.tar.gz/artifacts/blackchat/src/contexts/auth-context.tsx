import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import {
  User,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth'
import { ref, get } from 'firebase/database'
import { auth, database, isFirebaseConfigured } from '@/lib/firebase'

interface UserProfile {
  uid: string
  email: string
  name: string
  bio: string
  emoji: string
  publicId: string
  createdAt: number
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  loading: boolean
  isConfigured: boolean
  signUp: (email: string, password: string) => Promise<User>
  logIn: (email: string, password: string) => Promise<User>
  logOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  const fetchUserProfile = async (uid: string) => {
    if (!database) return
    try {
      const userRef = ref(database, `users/${uid}`)
      const snapshot = await get(userRef)
      if (snapshot.exists()) {
        setUserProfile(snapshot.val())
      } else {
        setUserProfile(null)
      }
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string }
      // Permission denied means database rules aren't set up yet — treat as no profile
      if (err?.code === 'PERMISSION_DENIED' || err?.message?.includes('Permission denied')) {
        console.warn('Firebase Database permission denied. Please update your Realtime Database security rules to allow authenticated access.')
        setUserProfile(null)
      } else {
        console.error('Error fetching user profile:', error)
        setUserProfile(null)
      }
    }
  }

  const refreshProfile = async () => {
    if (user) {
      await fetchUserProfile(user.uid)
    }
  }

  useEffect(() => {
    if (!auth || !isFirebaseConfigured) {
      setLoading(false)
      return
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser)
      if (firebaseUser) {
        await fetchUserProfile(firebaseUser.uid)
      } else {
        setUserProfile(null)
      }
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signUp = async (email: string, password: string) => {
    if (!auth) throw new Error('Firebase not configured')
    const result = await createUserWithEmailAndPassword(auth, email, password)
    return result.user
  }

  const logIn = async (email: string, password: string) => {
    if (!auth) throw new Error('Firebase not configured')
    const result = await signInWithEmailAndPassword(auth, email, password)
    return result.user
  }

  const logOut = async () => {
    if (!auth) throw new Error('Firebase not configured')
    await signOut(auth)
    setUserProfile(null)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        isConfigured: isFirebaseConfigured,
        signUp,
        logIn,
        logOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
