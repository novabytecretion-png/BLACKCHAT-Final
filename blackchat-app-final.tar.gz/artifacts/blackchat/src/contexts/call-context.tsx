import { createContext, useContext, useState, useRef, useCallback, ReactNode, useEffect } from 'react'
import { ref, set, onValue, remove, push, serverTimestamp, get } from 'firebase/database'
import { database, isFirebaseConfigured } from '@/lib/firebase'
import { useAuth } from './auth-context'

interface CallState {
  isInCall: boolean
  callType: 'voice' | 'video' | null
  callId: string | null
  remoteUserId: string | null
  remoteUserName: string | null
  remoteUserEmoji: string | null
  isIncoming: boolean
  callStatus: 'idle' | 'ringing' | 'connecting' | 'connected' | 'ended'
  isMuted: boolean
  isVideoOff: boolean
  callStartTime: number | null
}

interface CallContextType {
  callState: CallState
  localStream: MediaStream | null
  remoteStream: MediaStream | null
  initiateCall: (userId: string, userName: string, userEmoji: string, type: 'voice' | 'video') => Promise<void>
  acceptCall: () => Promise<void>
  rejectCall: () => void
  endCall: () => void
  toggleMute: () => void
  toggleVideo: () => void
  incomingCall: { callId: string; callerId: string; callerName: string; callerEmoji: string; type: 'voice' | 'video' } | null
}

const CallContext = createContext<CallContextType | null>(null)

const initialCallState: CallState = {
  isInCall: false,
  callType: null,
  callId: null,
  remoteUserId: null,
  remoteUserName: null,
  remoteUserEmoji: null,
  isIncoming: false,
  callStatus: 'idle',
  isMuted: false,
  isVideoOff: false,
  callStartTime: null,
}

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
}

export function CallProvider({ children }: { children: ReactNode }) {
  const { user, userProfile } = useAuth()
  const [callState, setCallState] = useState<CallState>(initialCallState)
  const [localStream, setLocalStream] = useState<MediaStream | null>(null)
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null)
  const [incomingCall, setIncomingCall] = useState<CallContextType['incomingCall']>(null)

  const peerConnection = useRef<RTCPeerConnection | null>(null)
  const callRef = useRef<string | null>(null)

  useEffect(() => {
    if (!user || !database || !isFirebaseConfigured) return

    const incomingCallsRef = ref(database, `calls/${user.uid}/incoming`)
    const unsubscribe = onValue(incomingCallsRef, (snapshot) => {
      if (snapshot.exists() && !callState.isInCall) {
        const data = snapshot.val()
        setIncomingCall({
          callId: data.callId,
          callerId: data.callerId,
          callerName: data.callerName,
          callerEmoji: data.callerEmoji,
          type: data.type,
        })
      }
    })

    return () => unsubscribe()
  }, [user, callState.isInCall])

  const endCall = useCallback(async () => {
    if (user && database && callState.callId && callState.remoteUserId) {
      const duration = callState.callStartTime ? Math.floor((Date.now() - callState.callStartTime) / 1000) : 0
      const callLogRef = ref(database, `callLogs/${user.uid}`)
      await push(callLogRef, {
        recipientId: callState.remoteUserId,
        recipientName: callState.remoteUserName,
        recipientEmoji: callState.remoteUserEmoji,
        type: callState.callType,
        duration,
        timestamp: serverTimestamp(),
        isOutgoing: !callState.isIncoming,
      })

      const remoteCallLogRef = ref(database, `callLogs/${callState.remoteUserId}`)
      await push(remoteCallLogRef, {
        recipientId: user.uid,
        recipientName: userProfile?.name,
        recipientEmoji: userProfile?.emoji,
        type: callState.callType,
        duration,
        timestamp: serverTimestamp(),
        isOutgoing: callState.isIncoming,
      })
    }

    if (callRef.current && database) {
      await set(ref(database, `callSessions/${callRef.current}/status`), 'ended')
    }

    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop())
    }
    if (peerConnection.current) {
      peerConnection.current.close()
    }

    setLocalStream(null)
    setRemoteStream(null)
    peerConnection.current = null
    callRef.current = null
    setCallState(initialCallState)
  }, [user, userProfile, callState, localStream])

  const createPeerConnection = useCallback(() => {
    const pc = new RTCPeerConnection(ICE_SERVERS)

    pc.onicecandidate = (event) => {
      if (event.candidate && callRef.current && database) {
        const candidatesRef = ref(database, `callSessions/${callRef.current}/candidates/${user?.uid}`)
        push(candidatesRef, event.candidate.toJSON())
      }
    }

    pc.ontrack = (event) => {
      setRemoteStream(event.streams[0])
    }

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        setCallState((prev) => ({
          ...prev,
          callStatus: 'connected',
          callStartTime: Date.now(),
        }))
      } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        endCall()
      }
    }

    peerConnection.current = pc
    return pc
  }, [user, endCall])

  const getMediaStream = async (type: 'voice' | 'video') => {
    const constraints = { audio: true, video: type === 'video' }
    return await navigator.mediaDevices.getUserMedia(constraints)
  }

  const initiateCall = async (userId: string, userName: string, userEmoji: string, type: 'voice' | 'video') => {
    if (!user || !userProfile || !database) return

    try {
      const stream = await getMediaStream(type)
      setLocalStream(stream)

      const pc = createPeerConnection()
      stream.getTracks().forEach((track) => pc.addTrack(track, stream))

      const callId = `${user.uid}_${userId}_${Date.now()}`
      callRef.current = callId

      await set(ref(database, `callSessions/${callId}`), {
        callerId: user.uid,
        receiverId: userId,
        type,
        status: 'ringing',
        createdAt: serverTimestamp(),
      })

      await set(ref(database, `calls/${userId}/incoming`), {
        callId,
        callerId: user.uid,
        callerName: userProfile.name,
        callerEmoji: userProfile.emoji,
        type,
      })

      const offer = await pc.createOffer()
      await pc.setLocalDescription(offer)
      await set(ref(database, `callSessions/${callId}/offer`), {
        type: offer.type,
        sdp: offer.sdp,
      })

      setCallState({
        isInCall: true,
        callType: type,
        callId,
        remoteUserId: userId,
        remoteUserName: userName,
        remoteUserEmoji: userEmoji,
        isIncoming: false,
        callStatus: 'ringing',
        isMuted: false,
        isVideoOff: false,
        callStartTime: null,
      })

      const answerRef = ref(database, `callSessions/${callId}/answer`)
      onValue(answerRef, async (snapshot) => {
        if (snapshot.exists() && pc.currentRemoteDescription === null) {
          const answer = snapshot.val()
          await pc.setRemoteDescription(new RTCSessionDescription(answer))
          setCallState((prev) => ({ ...prev, callStatus: 'connecting' }))
        }
      })

      const remoteCandidatesRef = ref(database, `callSessions/${callId}/candidates/${userId}`)
      onValue(remoteCandidatesRef, (snapshot) => {
        if (snapshot.exists()) {
          snapshot.forEach((child) => {
            const candidate = new RTCIceCandidate(child.val())
            pc.addIceCandidate(candidate)
          })
        }
      })

      const statusRef = ref(database, `callSessions/${callId}/status`)
      onValue(statusRef, (snapshot) => {
        if (snapshot.val() === 'rejected' || snapshot.val() === 'ended') {
          endCall()
        }
      })
    } catch (error) {
      console.error('Error initiating call:', error)
      endCall()
    }
  }

  const acceptCall = async () => {
    if (!incomingCall || !user || !database) return

    try {
      const { callId, callerId, callerName, callerEmoji, type } = incomingCall

      const stream = await getMediaStream(type)
      setLocalStream(stream)

      const pc = createPeerConnection()
      stream.getTracks().forEach((track) => pc.addTrack(track, stream))

      callRef.current = callId

      const offerSnapshot = await get(ref(database, `callSessions/${callId}/offer`))
      if (offerSnapshot.exists()) {
        const offer = offerSnapshot.val()
        await pc.setRemoteDescription(new RTCSessionDescription(offer))

        const answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)
        await set(ref(database, `callSessions/${callId}/answer`), {
          type: answer.type,
          sdp: answer.sdp,
        })
      }

      await remove(ref(database, `calls/${user.uid}/incoming`))

      setCallState({
        isInCall: true,
        callType: type,
        callId,
        remoteUserId: callerId,
        remoteUserName: callerName,
        remoteUserEmoji: callerEmoji,
        isIncoming: true,
        callStatus: 'connecting',
        isMuted: false,
        isVideoOff: false,
        callStartTime: null,
      })

      setIncomingCall(null)

      const remoteCandidatesRef = ref(database, `callSessions/${callId}/candidates/${callerId}`)
      onValue(remoteCandidatesRef, (snapshot) => {
        if (snapshot.exists()) {
          snapshot.forEach((child) => {
            const candidate = new RTCIceCandidate(child.val())
            pc.addIceCandidate(candidate)
          })
        }
      })

      const statusRef = ref(database, `callSessions/${callId}/status`)
      onValue(statusRef, (snapshot) => {
        if (snapshot.val() === 'ended') {
          endCall()
        }
      })
    } catch (error) {
      console.error('Error accepting call:', error)
      endCall()
    }
  }

  const rejectCall = async () => {
    if (!incomingCall || !user || !database) return
    await set(ref(database, `callSessions/${incomingCall.callId}/status`), 'rejected')
    await remove(ref(database, `calls/${user.uid}/incoming`))
    setIncomingCall(null)
  }

  const toggleMute = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0]
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled
        setCallState((prev) => ({ ...prev, isMuted: !audioTrack.enabled }))
      }
    }
  }

  const toggleVideo = () => {
    if (localStream) {
      const videoTrack = localStream.getVideoTracks()[0]
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled
        setCallState((prev) => ({ ...prev, isVideoOff: !videoTrack.enabled }))
      }
    }
  }

  return (
    <CallContext.Provider
      value={{
        callState,
        localStream,
        remoteStream,
        initiateCall,
        acceptCall,
        rejectCall,
        endCall,
        toggleMute,
        toggleVideo,
        incomingCall,
      }}
    >
      {children}
    </CallContext.Provider>
  )
}

export function useCall() {
  const context = useContext(CallContext)
  if (!context) {
    throw new Error('useCall must be used within a CallProvider')
  }
  return context
}
