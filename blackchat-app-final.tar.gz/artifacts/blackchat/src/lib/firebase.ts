import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app'
import { getAuth, Auth } from 'firebase/auth'
import { getDatabase, Database } from 'firebase/database'

const apiKey = import.meta.env.VITE_FIREBASE_API_KEY
const authDomain = import.meta.env.VITE_FIREBASE_AUTH_DOMAIN
const databaseURL = import.meta.env.VITE_FIREBASE_DATABASE_URL
const projectId = import.meta.env.VITE_FIREBASE_PROJECT_ID
const storageBucket = import.meta.env.VITE_FIREBASE_STORAGE_BUCKET
const messagingSenderId = import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID
const appId = import.meta.env.VITE_FIREBASE_APP_ID

const isValidDatabaseURL = (url: string) => {
  try {
    const parsed = new URL(url)
    return parsed.protocol === 'https:' && parsed.hostname.endsWith('.firebaseio.com')
  } catch {
    return false
  }
}

export const isFirebaseConfigured = Boolean(
  apiKey &&
  authDomain &&
  databaseURL &&
  isValidDatabaseURL(databaseURL) &&
  projectId &&
  appId
)

export const firebaseConfigError = !isFirebaseConfigured && databaseURL && !isValidDatabaseURL(databaseURL)
  ? `Invalid VITE_FIREBASE_DATABASE_URL: "${databaseURL}". It must be like: https://your-project-default-rtdb.firebaseio.com`
  : null

let app: FirebaseApp | null = null
let auth: Auth | null = null
let database: Database | null = null

if (isFirebaseConfigured) {
  const firebaseConfig = {
    apiKey,
    authDomain,
    databaseURL,
    projectId,
    storageBucket,
    messagingSenderId,
    appId,
  }

  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig)
    auth = getAuth(app)
    database = getDatabase(app)
  } catch (error) {
    console.error('Firebase initialization error:', error)
  }
}

export { app, auth, database }
