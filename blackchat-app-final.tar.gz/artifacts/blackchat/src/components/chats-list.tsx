import { useState, useEffect, useCallback } from 'react'
import { ref, onValue, get, query, orderByChild, limitToLast } from 'firebase/database'
import { database } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { EmojiAvatar } from './emoji-avatar'
import { formatDistanceToNow } from 'date-fns'
import { Search, MessageCircle } from 'lucide-react'
import { Input } from '@/components/ui/input'

interface Chat {
  odaId: string
  odaName: string
  odaEmoji: string
  lastMessage: string
  lastMessageTime: number
  unreadCount: number
}

interface ChatsListProps {
  onSelectChat: (chatId: string, name: string, emoji: string) => void
  selectedChatId: string | null
}

export function ChatsList({ onSelectChat, selectedChatId }: ChatsListProps) {
  const { user } = useAuth()
  const [chats, setChats] = useState<Chat[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)

  const loadChats = useCallback(async () => {
    if (!user || !database) return

    const contactsRef = ref(database, `contacts/${user.uid}`)

    const unsubscribe = onValue(contactsRef, async (snapshot) => {
      if (!snapshot.exists()) {
        setChats([])
        setLoading(false)
        return
      }

      const contactsData = snapshot.val()
      const chatPromises = Object.entries(contactsData).map(async ([odaId]) => {
        if (!database) return null
        const userRef = ref(database, `users/${odaId}`)
        const userSnapshot = await get(userRef)
        if (!userSnapshot.exists()) return null

        const odaData = userSnapshot.val()
        const chatId = [user.uid, odaId].sort().join('_')

        const messagesRef = query(
          ref(database, `messages/${chatId}`),
          orderByChild('timestamp'),
          limitToLast(1)
        )
        const messagesSnapshot = await get(messagesRef)
        let lastMessage = ''
        let lastMessageTime = 0

        if (messagesSnapshot.exists()) {
          const msgs = Object.values(messagesSnapshot.val()) as { text: string; timestamp: number }[]
          if (msgs.length > 0) {
            lastMessage = msgs[0].text
            lastMessageTime = msgs[0].timestamp
          }
        }

        const unreadRef = ref(database, `unread/${user.uid}/${odaId}`)
        const unreadSnapshot = await get(unreadRef)
        const unreadCount = unreadSnapshot.exists() ? unreadSnapshot.val() : 0

        return {
          odaId,
          odaName: odaData.name,
          odaEmoji: odaData.emoji,
          lastMessage,
          lastMessageTime,
          unreadCount,
        } as Chat
      })

      const chatResults = await Promise.all(chatPromises)
      const validChats = chatResults.filter((c): c is Chat => c !== null)
      validChats.sort((a, b) => b.lastMessageTime - a.lastMessageTime)
      setChats(validChats)
      setLoading(false)
    })

    return unsubscribe
  }, [user])

  useEffect(() => {
    let cleanup: (() => void) | undefined
    loadChats().then((unsub) => {
      cleanup = unsub
    })
    return () => {
      if (cleanup) cleanup()
    }
  }, [loadChats])

  useEffect(() => {
    if (!user || !database) return

    const unreadRef = ref(database, `unread/${user.uid}`)
    const unsubscribe = onValue(unreadRef, () => {
      loadChats()
    })

    return () => unsubscribe()
  }, [user, loadChats])

  const filteredChats = chats.filter((chat) =>
    chat.odaName.toLowerCase().includes(searchQuery.toLowerCase())
  )

  if (loading) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-border">
          <div className="h-10 bg-muted rounded-lg animate-pulse" />
        </div>
        <div className="flex-1 p-4 space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg">
              <div className="w-12 h-12 bg-muted rounded-full animate-pulse" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted rounded animate-pulse" />
                <div className="h-3 bg-muted rounded w-2/3 animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <MessageCircle className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">
              {searchQuery ? 'No chats found' : 'No conversations yet'}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Add contacts to start chatting
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredChats.map((chat) => (
              <button
                key={chat.odaId}
                onClick={() => onSelectChat(chat.odaId, chat.odaName, chat.odaEmoji)}
                className={`w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors text-left ${
                  selectedChatId === chat.odaId ? 'bg-muted' : ''
                }`}
              >
                <EmojiAvatar emoji={chat.odaEmoji} name={chat.odaName} size="lg" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-medium truncate">{chat.odaName}</span>
                    {chat.lastMessageTime > 0 && (
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(chat.lastMessageTime, { addSuffix: false })}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <p className="text-sm text-muted-foreground truncate max-w-[200px]">
                      {chat.lastMessage || 'No messages yet'}
                    </p>
                    {chat.unreadCount > 0 && (
                      <span className="min-w-[20px] h-5 px-1.5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                        {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
