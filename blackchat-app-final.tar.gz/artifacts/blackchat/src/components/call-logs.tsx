import { useState, useEffect } from 'react'
import { ref, onValue } from 'firebase/database'
import { database, isFirebaseConfigured } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { useCall } from '@/contexts/call-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Phone, Video, PhoneIncoming, PhoneOutgoing, Clock } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

interface CallLog {
  id: string
  recipientId: string
  recipientName: string
  recipientEmoji: string
  type: 'voice' | 'video'
  duration: number
  timestamp: number
  isOutgoing: boolean
}

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  if (mins < 60) return `${mins}m ${secs}s`
  const hours = Math.floor(mins / 60)
  const remainingMins = mins % 60
  return `${hours}h ${remainingMins}m`
}

export function CallLogs() {
  const { user } = useAuth()
  const { initiateCall } = useCall()
  const [callLogs, setCallLogs] = useState<CallLog[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)

  useEffect(() => {
    if (!user || !database || !isFirebaseConfigured) return

    const callLogsRef = ref(database, `callLogs/${user.uid}`)
    const unsubscribe = onValue(callLogsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const logs: CallLog[] = Object.entries(data).map(([id, log]) => ({
          id,
          ...(log as Omit<CallLog, 'id'>),
        }))
        logs.sort((a, b) => b.timestamp - a.timestamp)
        setCallLogs(logs)
      } else {
        setCallLogs([])
      }
    })

    return () => unsubscribe()
  }, [user])

  return (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon">
          <Phone className="w-5 h-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Call History</DialogTitle>
          <DialogDescription>Recent voice and video calls</DialogDescription>
        </DialogHeader>

        <div className="mt-4 max-h-[400px] overflow-y-auto">
          {callLogs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Phone className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No calls yet</p>
            </div>
          ) : (
            <div className="space-y-2">
              {callLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-center gap-3 p-3 hover:bg-muted rounded-lg transition-colors"
                >
                  <EmojiAvatar emoji={log.recipientEmoji} name={log.recipientName} size="md" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{log.recipientName}</span>
                      {log.isOutgoing ? (
                        <PhoneOutgoing className="w-3 h-3 text-muted-foreground" />
                      ) : (
                        <PhoneIncoming className="w-3 h-3 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      {log.type === 'video' ? (
                        <Video className="w-3 h-3" />
                      ) : (
                        <Phone className="w-3 h-3" />
                      )}
                      <span>{log.type === 'video' ? 'Video' : 'Voice'}</span>
                      <span>-</span>
                      <Clock className="w-3 h-3" />
                      <span>{formatDuration(log.duration)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(log.timestamp, { addSuffix: true })}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={() => {
                        setDialogOpen(false)
                        initiateCall(log.recipientId, log.recipientName, log.recipientEmoji, 'voice')
                      }}
                    >
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      onClick={() => {
                        setDialogOpen(false)
                        initiateCall(log.recipientId, log.recipientName, log.recipientEmoji, 'video')
                      }}
                    >
                      <Video className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
