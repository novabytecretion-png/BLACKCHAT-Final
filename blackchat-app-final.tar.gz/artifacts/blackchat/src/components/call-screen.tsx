import { useEffect, useRef, useState } from 'react'
import { useCall } from '@/contexts/call-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import { Mic, MicOff, Video, VideoOff, PhoneOff } from 'lucide-react'

export function CallScreen() {
  const {
    callState,
    localStream,
    remoteStream,
    endCall,
    toggleMute,
    toggleVideo,
  } = useCall()

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const [callDuration, setCallDuration] = useState(0)

  useEffect(() => {
    if (localStream && localVideoRef.current) {
      localVideoRef.current.srcObject = localStream
    }
  }, [localStream])

  useEffect(() => {
    if (remoteStream && remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = remoteStream
    }
  }, [remoteStream])

  useEffect(() => {
    if (callState.callStatus === 'connected' && callState.callStartTime) {
      const interval = setInterval(() => {
        setCallDuration(Math.floor((Date.now() - (callState.callStartTime as number)) / 1000))
      }, 1000)
      return () => clearInterval(interval)
    }
    return undefined
  }, [callState.callStatus, callState.callStartTime])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  if (!callState.isInCall) return null

  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col">
      <div className="flex-1 relative bg-muted">
        {callState.callType === 'video' ? (
          <>
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 right-4 w-32 h-48 md:w-48 md:h-64 rounded-2xl overflow-hidden shadow-lg border-2 border-background">
              {callState.isVideoOff ? (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                  <VideoOff className="w-8 h-8 text-muted-foreground" />
                </div>
              ) : (
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              )}
            </div>
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center">
            <div className={callState.callStatus === 'connected' ? 'animate-pulse' : ''}>
              <EmojiAvatar
                emoji={callState.remoteUserEmoji || '😀'}
                name={callState.remoteUserName || 'User'}
                size="xl"
              />
            </div>
            <h2 className="mt-6 text-2xl font-semibold">{callState.remoteUserName}</h2>
            <p className="mt-2 text-muted-foreground">
              {callState.callStatus === 'ringing' && 'Calling...'}
              {callState.callStatus === 'connecting' && 'Connecting...'}
              {callState.callStatus === 'connected' && formatDuration(callDuration)}
            </p>
          </div>
        )}
      </div>

      <div className="p-6 bg-card border-t border-border">
        <div className="flex items-center justify-center gap-4">
          <Button
            size="lg"
            variant="outline"
            className={`w-14 h-14 rounded-full ${callState.isMuted ? 'bg-destructive/10 border-destructive text-destructive' : ''}`}
            onClick={toggleMute}
          >
            {callState.isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </Button>

          {callState.callType === 'video' && (
            <Button
              size="lg"
              variant="outline"
              className={`w-14 h-14 rounded-full ${callState.isVideoOff ? 'bg-destructive/10 border-destructive text-destructive' : ''}`}
              onClick={toggleVideo}
            >
              {callState.isVideoOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </Button>
          )}

          <Button
            size="lg"
            variant="destructive"
            className="w-16 h-16 rounded-full"
            onClick={endCall}
          >
            <PhoneOff className="w-7 h-7" />
          </Button>
        </div>
      </div>
    </div>
  )
}
