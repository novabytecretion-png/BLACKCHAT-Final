import { useCall } from '@/contexts/call-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import { Phone, PhoneOff, Video } from 'lucide-react'

export function IncomingCall() {
  const { incomingCall, acceptCall, rejectCall } = useCall()

  if (!incomingCall) return null

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col items-center justify-center">
      <div className="text-center space-y-6">
        <div className="animate-bounce">
          <EmojiAvatar
            emoji={incomingCall.callerEmoji}
            name={incomingCall.callerName}
            size="xl"
          />
        </div>

        <div>
          <h2 className="text-2xl font-semibold">{incomingCall.callerName}</h2>
          <p className="text-muted-foreground mt-1 flex items-center justify-center gap-2">
            {incomingCall.type === 'video' ? (
              <>
                <Video className="w-4 h-4" />
                Incoming video call
              </>
            ) : (
              <>
                <Phone className="w-4 h-4" />
                Incoming voice call
              </>
            )}
          </p>
        </div>

        <div className="flex items-center justify-center gap-8 mt-8">
          <Button
            size="lg"
            variant="destructive"
            className="w-16 h-16 rounded-full"
            onClick={rejectCall}
          >
            <PhoneOff className="w-7 h-7" />
          </Button>

          <Button
            size="lg"
            className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600"
            onClick={acceptCall}
          >
            {incomingCall.type === 'video' ? (
              <Video className="w-7 h-7" />
            ) : (
              <Phone className="w-7 h-7" />
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
