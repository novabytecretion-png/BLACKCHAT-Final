import { useState, useEffect } from 'react'
import { ref, get, set, remove, onValue } from 'firebase/database'
import { database } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, UserPlus, Check, X, Loader2, Users, Bell } from 'lucide-react'
import { toast } from 'sonner'

interface UserData {
  uid: string
  name: string
  bio: string
  emoji: string
  publicId: string
}

interface FriendRequest {
  id: string
  fromUserId: string
  fromUserName: string
  fromUserEmoji: string
  fromUserBio: string
  timestamp: number
}

export function Contacts() {
  const { user } = useAuth()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResult, setSearchResult] = useState<UserData | null>(null)
  const [searching, setSearching] = useState(false)
  const [sendingRequest, setSendingRequest] = useState(false)
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([])
  const [contacts, setContacts] = useState<UserData[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [processingRequest, setProcessingRequest] = useState<string | null>(null)

  useEffect(() => {
    if (!user || !database) return

    const requestsRef = ref(database, `friendRequests/${user.uid}`)
    const unsubscribe = onValue(requestsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const requests: FriendRequest[] = Object.entries(data).map(([id, req]) => ({
          id,
          ...(req as Omit<FriendRequest, 'id'>),
        }))
        requests.sort((a, b) => b.timestamp - a.timestamp)
        setFriendRequests(requests)
      } else {
        setFriendRequests([])
      }
    })

    return () => unsubscribe()
  }, [user])

  useEffect(() => {
    if (!user || !database) return

    const contactsRef = ref(database, `contacts/${user.uid}`)
    const unsubscribe = onValue(contactsRef, async (snapshot) => {
      if (snapshot.exists() && database) {
        const contactIds = Object.keys(snapshot.val())
        const contactsData: UserData[] = []

        for (const contactId of contactIds) {
          const userRef = ref(database, `users/${contactId}`)
          const userSnapshot = await get(userRef)
          if (userSnapshot.exists()) {
            contactsData.push(userSnapshot.val())
          }
        }

        contactsData.sort((a, b) => a.name.localeCompare(b.name))
        setContacts(contactsData)
      } else {
        setContacts([])
      }
    })

    return () => unsubscribe()
  }, [user])

  const searchUser = async () => {
    if (!searchQuery.trim() || !user || !database) return

    setSearching(true)
    setSearchResult(null)

    try {
      const publicIdRef = ref(database, `publicIds/${searchQuery.toLowerCase()}`)
      const snapshot = await get(publicIdRef)

      if (snapshot.exists()) {
        const uid = snapshot.val()

        if (uid === user.uid) {
          toast.error("That's your own ID!")
          setSearching(false)
          return
        }

        const userRef = ref(database, `users/${uid}`)
        const userSnapshot = await get(userRef)

        if (userSnapshot.exists()) {
          setSearchResult(userSnapshot.val())
        }
      } else {
        toast.error('User not found')
      }
    } catch {
      toast.error('Failed to search user')
    } finally {
      setSearching(false)
    }
  }

  const sendFriendRequest = async () => {
    if (!searchResult || !user || !database) return

    setSendingRequest(true)
    try {
      const existingContactRef = ref(database, `contacts/${user.uid}/${searchResult.uid}`)
      const existingContact = await get(existingContactRef)
      if (existingContact.exists()) {
        toast.error('Already in contacts')
        setSendingRequest(false)
        return
      }

      const existingRequestRef = ref(database, `friendRequests/${searchResult.uid}/${user.uid}`)
      const existingRequest = await get(existingRequestRef)
      if (existingRequest.exists()) {
        toast.error('Request already sent')
        setSendingRequest(false)
        return
      }

      const senderProfile = await get(ref(database, `users/${user.uid}`))
      const senderData = senderProfile.val()

      await set(ref(database, `friendRequests/${searchResult.uid}/${user.uid}`), {
        fromUserId: user.uid,
        fromUserName: senderData.name,
        fromUserEmoji: senderData.emoji,
        fromUserBio: senderData.bio || '',
        timestamp: Date.now(),
      })

      toast.success('Friend request sent!')
      setSearchResult(null)
      setSearchQuery('')
    } catch {
      toast.error('Failed to send request')
    } finally {
      setSendingRequest(false)
    }
  }

  const acceptRequest = async (request: FriendRequest) => {
    if (!user || !database) return

    setProcessingRequest(request.id)
    try {
      await set(ref(database, `contacts/${user.uid}/${request.fromUserId}`), true)
      await set(ref(database, `contacts/${request.fromUserId}/${user.uid}`), true)
      await remove(ref(database, `friendRequests/${user.uid}/${request.fromUserId}`))
      toast.success(`${request.fromUserName} added to contacts!`)
    } catch {
      toast.error('Failed to accept request')
    } finally {
      setProcessingRequest(null)
    }
  }

  const rejectRequest = async (request: FriendRequest) => {
    if (!user || !database) return

    setProcessingRequest(request.id)
    try {
      await remove(ref(database, `friendRequests/${user.uid}/${request.fromUserId}`))
    } catch {
      toast.error('Failed to reject request')
    } finally {
      setProcessingRequest(null)
    }
  }

  return (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Users className="w-5 h-5" />
          {friendRequests.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-primary-foreground text-[10px] rounded-full flex items-center justify-center">
              {friendRequests.length}
            </span>
          )}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Contacts</DialogTitle>
          <DialogDescription>Find and manage your contacts</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="search" className="mt-4">
          <TabsList className="w-full">
            <TabsTrigger value="search" className="flex-1">Find Users</TabsTrigger>
            <TabsTrigger value="requests" className="flex-1">
              Requests
              {friendRequests.length > 0 && (
                <span className="ml-2 w-4 h-4 bg-primary text-primary-foreground text-[10px] rounded-full flex items-center justify-center">
                  {friendRequests.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="contacts" className="flex-1">Contacts</TabsTrigger>
          </TabsList>

          <TabsContent value="search" className="mt-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by public ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && searchUser()}
                  className="pl-9"
                />
              </div>
              <Button onClick={searchUser} disabled={searching || !searchQuery.trim()}>
                {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </Button>
            </div>

            {searchResult && (
              <div className="mt-4 p-4 bg-muted rounded-lg">
                <div className="flex items-center gap-3">
                  <EmojiAvatar emoji={searchResult.emoji} name={searchResult.name} size="md" />
                  <div className="flex-1">
                    <p className="font-medium">{searchResult.name}</p>
                    <p className="text-sm text-muted-foreground">@{searchResult.publicId}</p>
                    {searchResult.bio && (
                      <p className="text-xs text-muted-foreground mt-1">{searchResult.bio}</p>
                    )}
                  </div>
                  <Button size="sm" onClick={sendFriendRequest} disabled={sendingRequest}>
                    {sendingRequest ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <UserPlus className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="requests" className="mt-4">
            {friendRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No pending requests</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {friendRequests.map((request) => (
                  <div key={request.id} className="flex items-center gap-3 p-3 hover:bg-muted rounded-lg transition-colors">
                    <EmojiAvatar emoji={request.fromUserEmoji} name={request.fromUserName} size="md" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium">{request.fromUserName}</p>
                      {request.fromUserBio && (
                        <p className="text-xs text-muted-foreground truncate">{request.fromUserBio}</p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-green-500 hover:text-green-500 hover:bg-green-500/10"
                        onClick={() => acceptRequest(request)}
                        disabled={processingRequest === request.id}
                      >
                        {processingRequest === request.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => rejectRequest(request)}
                        disabled={processingRequest === request.id}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="contacts" className="mt-4">
            {contacts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No contacts yet</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {contacts.map((contact) => (
                  <div key={contact.uid} className="flex items-center gap-3 p-3 hover:bg-muted rounded-lg transition-colors">
                    <EmojiAvatar emoji={contact.emoji} name={contact.name} size="md" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium">{contact.name}</p>
                      <p className="text-sm text-muted-foreground">@{contact.publicId}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
