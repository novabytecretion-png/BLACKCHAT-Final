interface AvatarProps {
  emoji: string
  name: string
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

const sizeMap = {
  sm: { container: 'w-8 h-8', text: 'text-sm' },
  md: { container: 'w-10 h-10', text: 'text-lg' },
  lg: { container: 'w-14 h-14', text: 'text-2xl' },
  xl: { container: 'w-20 h-20', text: 'text-4xl' },
}

const colorPalette = [
  'bg-red-500',
  'bg-orange-500',
  'bg-amber-500',
  'bg-yellow-500',
  'bg-lime-500',
  'bg-green-500',
  'bg-teal-500',
  'bg-cyan-500',
  'bg-blue-500',
  'bg-violet-500',
  'bg-purple-500',
  'bg-pink-500',
]

function getColorFromName(name: string): string {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash)
  }
  return colorPalette[Math.abs(hash) % colorPalette.length]
}

export function EmojiAvatar({ emoji, name, size = 'md', className = '' }: AvatarProps) {
  const { container, text } = sizeMap[size]
  const bgColor = getColorFromName(name || 'user')

  return (
    <div
      className={`${container} ${bgColor} rounded-full flex items-center justify-center flex-shrink-0 ${className}`}
      title={name}
    >
      <span className={`${text} select-none leading-none`} role="img" aria-label={name}>
        {emoji || '😀'}
      </span>
    </div>
  )
}
