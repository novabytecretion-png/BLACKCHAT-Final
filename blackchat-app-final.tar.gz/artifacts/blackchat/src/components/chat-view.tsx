import { useState, useEffect, useRef, useCallback } from 'react'
import { ref, push, onValue, set, remove, get } from 'firebase/database'
import { database } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { useCall } from '@/contexts/call-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Send, ArrowLeft, Phone, Video, MoreVertical, Trash2, Smile } from 'lucide-react'
import { format, isToday, isYesterday } from 'date-fns'

interface Message {
  id: string
  senderId: string
  text: string
  timestamp: number
  messageType: 'text' | 'emoji'
}

interface ChatViewProps {
  chatUserId: string
  chatUserName: string
  chatUserEmoji: string
  onBack: () => void
}

const QUICK_EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🙏', '🎉', '🔥']

export function ChatView({ chatUserId, chatUserName, chatUserEmoji, onBack }: ChatViewProps) {
  const { user } = useAuth()
  const { initiateCall } = useCall()
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [remoteTyping, setRemoteTyping] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [showClearDialog, setShowClearDialog] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const chatId = user ? [user.uid, chatUserId].sort().join('_') : ''

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    if (!chatId || !database) return

    const messagesRef = ref(database, `messages/${chatId}`)
    const unsubscribe = onValue(messagesRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val()
        const messageList: Message[] = Object.entries(data).map(([id, msg]) => ({
          id,
          ...(msg as Omit<Message, 'id'>),
        }))
        messageList.sort((a, b) => a.timestamp - b.timestamp)
        setMessages(messageList)
      } else {
        setMessages([])
      }
    })

    return () => unsubscribe()
  }, [chatId])

  useEffect(() => {
    if (!user || !chatUserId || !database) return
    const unreadRef = ref(database, `unread/${user.uid}/${chatUserId}`)
    set(unreadRef, 0)
  }, [user, chatUserId, messages])

  useEffect(() => {
    if (!chatId || !user || !database) return

    const typingRef = ref(database, `typing/${chatId}/${chatUserId}`)
    const unsubscribe = onValue(typingRef, (snapshot) => {
      setRemoteTyping(snapshot.exists() && snapshot.val() === true)
    })

    return () => unsubscribe()
  }, [chatId, chatUserId, user])

  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  const handleTyping = () => {
    if (!chatId || !user || !database) return

    if (!isTyping) {
      setIsTyping(true)
      set(ref(database, `typing/${chatId}/${user.uid}`), true)
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current)
    }

    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false)
      if (database) remove(ref(database, `typing/${chatId}/${user.uid}`))
    }, 2000)
  }

  const sendMessage = async (text: string, type: 'text' | 'emoji' = 'text') => {
    if (!user || !chatId || !database) return

    const messagesRef = ref(database, `messages/${chatId}`)
    await push(messagesRef, {
      senderId: user.uid,
      text,
      timestamp: Date.now(),
      messageType: type,
    })

    const unreadRef = ref(database, `unread/${chatUserId}/${user.uid}`)
    const unreadSnapshot = await get(unreadRef)
    const currentUnread = unreadSnapshot.exists() ? unreadSnapshot.val() : 0
    await set(unreadRef, currentUnread + 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return
    await sendMessage(newMessage.trim())
    setNewMessage('')
    setIsTyping(false)
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    if (database && chatId && user) {
      remove(ref(database, `typing/${chatId}/${user.uid}`))
    }
  }

  const clearChat = async () => {
    if (!chatId || !database) return
    await remove(ref(database, `messages/${chatId}`))
    setShowClearDialog(false)
  }

  const formatMessageTime = (timestamp: number) => {
    const date = new Date(timestamp)
    if (isToday(date)) return format(date, 'HH:mm')
    if (isYesterday(date)) return `Yesterday ${format(date, 'HH:mm')}`
    return format(date, 'MMM d, HH:mm')
  }

  const groupMessagesByDate = (msgs: Message[]) => {
    const groups: { date: string; messages: Message[] }[] = []
    let currentDate = ''

    msgs.forEach((msg) => {
      const date = new Date(msg.timestamp)
      const dateStr = isToday(date) ? 'Today' : isYesterday(date) ? 'Yesterday' : format(date, 'MMMM d, yyyy')

      if (dateStr !== currentDate) {
        currentDate = dateStr
        groups.push({ date: dateStr, messages: [msg] })
      } else {
        groups[groups.length - 1].messages.push(msg)
      }
    })

    return groups
  }

  const messageGroups = groupMessagesByDate(messages)

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border bg-card">
        <Button variant="ghost" size="icon" onClick={onBack} className="md:hidden">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <EmojiAvatar emoji={chatUserEmoji} name={chatUserName} size="md" />
        <div className="flex-1">
          <h2 className="font-semibold">{chatUserName}</h2>
          {remoteTyping && (
            <p className="text-xs text-muted-foreground animate-pulse">typing...</p>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => initiateCall(chatUserId, chatUserName, chatUserEmoji, 'voice')}
          >
            <Phone className="w-5 h-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => initiateCall(chatUserId, chatUserName, chatUserEmoji, 'video')}
          >
            <Video className="w-5 h-5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-destructive"
                onClick={() => setShowClearDialog(true)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear Chat
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messageGroups.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <EmojiAvatar emoji={chatUserEmoji} name={chatUserName} size="lg" className="mb-4" />
            <p className="font-medium">{chatUserName}</p>
            <p className="text-sm text-muted-foreground mt-1">Start your conversation</p>
          </div>
        ) : (
          messageGroups.map((group) => (
            <div key={group.date}>
              <div className="flex items-center gap-2 my-4">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-muted-foreground px-2">{group.date}</span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <div className="space-y-2">
                {group.messages.map((msg) => {
                  const isOwn = msg.senderId === user?.uid
                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[75%] ${
                          msg.messageType === 'emoji'
                            ? 'text-4xl'
                            : `rounded-2xl px-4 py-2 ${
                                isOwn
                                  ? 'bg-primary text-primary-foreground rounded-br-sm'
                                  : 'bg-muted rounded-bl-sm'
                              }`
                        }`}
                      >
                        <p className={msg.messageType === 'emoji' ? 'text-4xl' : 'text-sm'}>
                          {msg.text}
                        </p>
                        {msg.messageType !== 'emoji' && (
                          <p
                            className={`text-[10px] mt-1 ${
                              isOwn ? 'text-primary-foreground/70 text-right' : 'text-muted-foreground'
                            }`}
                          >
                            {formatMessageTime(msg.timestamp)}
                          </p>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Emoji Picker */}
      {showEmojiPicker && (
        <div className="px-4 py-2 border-t border-border bg-card">
          <div className="flex gap-2">
            {QUICK_EMOJIS.map((emoji) => (
              <button
                key={emoji}
                className="text-2xl hover:scale-125 transition-transform"
                onClick={() => {
                  sendMessage(emoji, 'emoji')
                  setShowEmojiPicker(false)
                }}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-border bg-card">
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
          >
            <Smile className="w-5 h-5" />
          </Button>
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => {
              setNewMessage(e.target.value)
              handleTyping()
            }}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={!newMessage.trim()}>
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </form>

      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear Chat History</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all messages in this conversation. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={clearChat}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Clear Chat
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
