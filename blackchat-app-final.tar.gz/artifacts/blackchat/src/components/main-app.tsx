import { useState, useEffect } from 'react'
import { useLocation } from 'wouter'
import { useAuth } from '@/contexts/auth-context'
import { ChatsList } from './chats-list'
import { ChatView } from './chat-view'
import { Contacts } from './contacts'
import { CallLogs } from './call-logs'
import { Settings } from './settings'
import { CallScreen } from './call-screen'
import { IncomingCall } from './incoming-call'
import { EmojiAvatar } from './emoji-avatar'
import { MessageCircle, Loader2, AlertTriangle, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { firebaseConfigError } from '@/lib/firebase'

export function MainApp() {
  const { user, userProfile, loading, isConfigured } = useAuth()
  const [, navigate] = useLocation()
  const [selectedChat, setSelectedChat] = useState<{
    userId: string
    name: string
    emoji: string
  } | null>(null)

  useEffect(() => {
    if (!loading && isConfigured) {
      if (!user) {
        navigate('/auth')
      } else if (!userProfile) {
        navigate('/setup')
      }
    }
  }, [user, userProfile, loading, navigate, isConfigured])

  if (!isConfigured) {
    return (
      <div className="h-screen flex items-center justify-center bg-background p-4">
        <div className="max-w-lg w-full text-center">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertTriangle className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Firebase Configuration Required</h1>
          <p className="text-muted-foreground mb-6">
            Black Chat requires Firebase to be configured. Please add your Firebase credentials to continue.
          </p>

          <div className="bg-card border border-border rounded-lg p-6 text-left mb-6">
            <h2 className="font-semibold mb-4">Required Environment Variables:</h2>
            <ul className="space-y-2 text-sm font-mono text-muted-foreground">
              <li>VITE_FIREBASE_API_KEY</li>
              <li>VITE_FIREBASE_AUTH_DOMAIN</li>
              <li>VITE_FIREBASE_DATABASE_URL</li>
              <li>VITE_FIREBASE_PROJECT_ID</li>
              <li>VITE_FIREBASE_STORAGE_BUCKET</li>
              <li>VITE_FIREBASE_MESSAGING_SENDER_ID</li>
              <li>VITE_FIREBASE_APP_ID</li>
            </ul>
          </div>

          {firebaseConfigError && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 text-left mb-4">
              <p className="text-sm font-semibold text-destructive mb-1">Configuration Error:</p>
              <p className="text-xs text-destructive/80 break-all">{firebaseConfigError}</p>
            </div>
          )}

          <div className="space-y-3">
            <Button asChild className="w-full">
              <a
                href="https://console.firebase.google.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open Firebase Console
              </a>
            </Button>
            <p className="text-xs text-muted-foreground">
              Create a Firebase project, enable Authentication (Email/Password) and Realtime Database, then add your credentials via Secrets.
            </p>
          </div>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user || !userProfile) {
    return null
  }

  return (
    <div className="h-screen flex bg-background">
      <div
        className={`w-full md:w-80 lg:w-96 border-r border-border flex flex-col ${
          selectedChat ? 'hidden md:flex' : 'flex'
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-border bg-card">
          <div className="flex items-center gap-3">
            <EmojiAvatar emoji={userProfile.emoji} name={userProfile.name} size="md" />
            <div>
              <h1 className="font-semibold flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Black Chat
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Contacts />
            <CallLogs />
            <Settings />
          </div>
        </div>

        <div className="flex-1 overflow-hidden">
          <ChatsList
            onSelectChat={(userId, name, emoji) => setSelectedChat({ userId, name, emoji })}
            selectedChatId={selectedChat?.userId || null}
          />
        </div>
      </div>

      <div className={`flex-1 ${selectedChat ? 'flex' : 'hidden md:flex'}`}>
        {selectedChat ? (
          <div className="w-full">
            <ChatView
              chatUserId={selectedChat.userId}
              chatUserName={selectedChat.name}
              chatUserEmoji={selectedChat.emoji}
              onBack={() => setSelectedChat(null)}
            />
          </div>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-center p-8 bg-muted/30">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-4">
              <MessageCircle className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold">Welcome to Black Chat</h2>
            <p className="text-muted-foreground mt-2 max-w-md">
              Select a conversation from the list or add new contacts to start chatting
            </p>
          </div>
        )}
      </div>

      <CallScreen />
      <IncomingCall />
    </div>
  )
}
