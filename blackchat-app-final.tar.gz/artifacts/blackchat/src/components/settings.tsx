import { useState } from 'react'
import { useLocation } from 'wouter'
import { ref, update } from 'firebase/database'
import { database, isFirebaseConfigured } from '@/lib/firebase'
import { useAuth } from '@/contexts/auth-context'
import { useTheme } from '@/contexts/theme-context'
import { EmojiAvatar } from './emoji-avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Settings as SettingsIcon, Moon, Sun, LogOut, Save, Loader2, User, FileText, Smile } from 'lucide-react'
import { toast } from 'sonner'

const POPULAR_EMOJIS = ['😀', '😎', '🚀', '💬', '🔥', '⭐', '💡', '🎯', '🌟', '💪', '🎉', '❤️', '🌈', '🦄', '🐱', '🐶', '🦊', '🐼', '🦁', '🐸']

export function Settings() {
  const { user, userProfile, logOut, refreshProfile } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const [, navigate] = useLocation()
  const [open, setOpen] = useState(false)
  const [saving, setSaving] = useState(false)

  const [name, setName] = useState(userProfile?.name || '')
  const [bio, setBio] = useState(userProfile?.bio || '')
  const [emoji, setEmoji] = useState(userProfile?.emoji || '😀')

  const handleSave = async () => {
    if (!user || !userProfile || !database) return

    if (!name.trim()) {
      toast.error('Name is required')
      return
    }

    if (name.length > 20) {
      toast.error('Name must be 20 characters or less')
      return
    }

    if (bio.length > 100) {
      toast.error('Bio must be 100 characters or less')
      return
    }

    setSaving(true)
    try {
      await update(ref(database, `users/${user.uid}`), {
        name: name.trim(),
        bio: bio.trim(),
        emoji,
      })
      await refreshProfile()
      toast.success('Profile updated!')
    } catch {
      toast.error('Failed to update profile')
    } finally {
      setSaving(false)
    }
  }

  const handleLogout = async () => {
    await logOut()
    navigate('/auth')
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon">
          <SettingsIcon className="w-5 h-5" />
        </Button>
      </SheetTrigger>
      <SheetContent className="overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Settings</SheetTitle>
          <SheetDescription>Manage your profile and preferences</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <EmojiAvatar emoji={emoji} name={name || 'User'} size="lg" />
            <div>
              <p className="font-medium">{name || 'Your Name'}</p>
              <p className="text-sm text-muted-foreground">@{userProfile?.publicId}</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Name
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={20}
            />
            <p className="text-xs text-muted-foreground text-right">{name.length}/20</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Bio
            </Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              maxLength={100}
              rows={3}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground text-right">{bio.length}/100</p>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Smile className="w-4 h-4" />
              Emoji
            </Label>
            <div className="grid grid-cols-10 gap-2">
              {POPULAR_EMOJIS.map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => setEmoji(e)}
                  className={`w-8 h-8 flex items-center justify-center rounded-lg transition-all ${
                    emoji === e ? 'bg-primary text-primary-foreground scale-110' : 'hover:bg-muted'
                  }`}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving} className="w-full">
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>

          <div className="border-t border-border pt-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                <Label>Dark Mode</Label>
              </div>
              <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
            </div>

            <Button variant="destructive" onClick={handleLogout} className="w-full">
              <LogOut className="w-4 h-4 mr-2" />
              Log Out
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
